// UI helpers: toast notifications + small utils
(function(){
  function ensureToastHost(){
    let host = document.getElementById('toast-host');
    if (!host){
      host = document.createElement('div');
      host.id = 'toast-host';
      host.className = 'toast-host';
      document.body.appendChild(host);
    }
    return host;
  }

  window.toast = function(message, type='info', timeout=2600){
    const host = ensureToastHost();
    const el = document.createElement('div');
    el.className = `toast toast-${type}`;
    el.textContent = message;
    host.appendChild(el);
    requestAnimationFrame(()=> el.classList.add('show'));
    setTimeout(()=>{
      el.classList.remove('show');
      setTimeout(()=> el.remove(), 250);
    }, timeout);
  };

  window.confirmDialog = function(message){
    return Promise.resolve(window.confirm(message));
  };
})();

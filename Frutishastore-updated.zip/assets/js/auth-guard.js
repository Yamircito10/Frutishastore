// Auth guard + sidebar behavior
(function(){
  const user = localStorage.getItem("usuarioActivo");
  const rol  = localStorage.getItem("rolActivo");

  // If we're not on login page, require session
  const isLogin = /login\.html$/i.test(location.pathname) || document.body.classList.contains('page-login');
  if (!isLogin && !user){
    location.href = "login.html";
    return;
  }

  // Admin-only links visibility
  document.querySelectorAll(".admin-only").forEach(el=>{
    el.style.display = (rol === "admin") ? "" : "none";
  });

  // User pill
  const pill = document.getElementById("user-pill");
  if (pill && user){
    pill.textContent = `${user} · ${rol || "usuario"}`;
  }

  // Logout
  const btnLogout = document.getElementById("btn-logout");
  if (btnLogout){
    btnLogout.addEventListener("click", ()=>{
      localStorage.removeItem("usuarioActivo");
      localStorage.removeItem("rolActivo");
      location.href = "login.html";
    });
  }

  // Active nav
  const file = (location.pathname.split("/").pop() || "index.html").toLowerCase();
  document.querySelectorAll(".nav-link").forEach(a=>{
    const href = (a.getAttribute("href")||"").toLowerCase();
    if (href === file) a.classList.add("active");
  });

  // Mobile sidebar
  const btnMenu = document.getElementById("btn-menu");
  const shell = document.querySelector(".app-shell");
  if (btnMenu && shell){
    btnMenu.addEventListener("click", ()=> shell.classList.toggle("sidebar-open"));
  }

  // Page title
  const titleEl = document.getElementById("page-title");
  if (titleEl){
    const map = {
      "index.html":"Dashboard",
      "inventario.html":"Inventario",
      "importar.html":"Importar",
      "historial.html":"Historial",
      "reporte-tallas.html":"Reporte de tallas",
    };
    titleEl.textContent = map[file] || "Frutisha Admin";
  }
})();

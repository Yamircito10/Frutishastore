// Firebase init (shared)
(function(){
  const firebaseConfig = {
    apiKey: "AIzaSyBtNWOs53cdTm0SYUZeqCQb4OC-VdcMQ",
    authDomain: "frutisha-store.firebaseapp.com",
    projectId: "inventario-ab270",
    storageBucket: "frutisha-store.appspot.com",
    messagingSenderId: "15388676345",
    appId: "1:15388676345:web:72c8e22a2aece1d4151228"
  };

  if (!window.firebase) {
    console.error("Firebase SDK no cargado. Revisa los <script> de firebase-app y firebase-firestore.");
    return;
  }
  if (!firebase.apps || !firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
  }
  window.db = firebase.firestore();
})();
